#edit  ~ @lMl10l for l313l 

from telethon import events
from JoKeRUB.utils import admin_cmd
from JoKeRUB import l313l
from . import *

#edit  ~ @lMl10l for l313l 
#جميع الحقوق محفوظة لسـورس الجوكر تخـمط تبيـن فشلـك


plugin_category = "extra"
@l313l.ar_cmd(
    pattern="ك1$",
    command=("ك1", plugin_category),
           )
async def tmgif(event):
    if event.fwd_from:
        return
    ROZ = await reply_id(event)
    if cute:
        l313l = f"**{ROZA}**\n"
        l313l += f"✛━━━━━━━━━━━━━✛\n"
        l313l += f"**الـمتحـرڪـة الأولـى **"
        await event.client.send_file(event.chat_id, cute, caption=l313l, reply_to=ROZ)

#edit  ~ @lMl10l for l313l 
#جميع الحقوق محفوظة لسـورس الجوكر تخـمط تبيـن فشلـك

@l313l.ar_cmd(
    pattern="ك2$",
    command=("ك2", plugin_category),
           )
async def tmgif(event):
    if event.fwd_from:
        return
    leo = await reply_id(event)
    if cute2:
        RAZAN = f"**{ROZA}**\n"
        RAZAN += f"✛━━━━━━━━━━━━━✛\n"
        RAZAN += f"**الـمتحـرڪـة الـثـانيـة **\n"
        await event.client.send_file(event.chat_id, cute2, caption=RAZAN, reply_to=leo)

#edit  ~ @lMl10l for l313l 
#جميع الحقوق محفوظة لسـورس الجوكر تخـمط تبيـن فشلـك

@l313l.ar_cmd(
    pattern="ك3$",
    command=("ك3", plugin_category),
           )
async def tmgif(event):
    if event.fwd_from:
        return
    sic_id = await reply_id(event)
    if cute3:
        RAZAN = f"**{ROZA}**\n"
        RAZAN += f"✛━━━━━━━━━━━━━✛\n"
        RAZAN += f"**الـمتحـرڪـة الـثـالثـة**\n"
        await event.client.send_file(event.chat_id, cute3, caption=RAZAN, reply_to=sic_id)

#edit  ~ @lMl10l for l313l 
#جميع الحقوق محفوظة لسـورس الجوكر تخـمط تبيـن فشلـك

@l313l.ar_cmd(
    pattern="ك4$",
    command=("ك4", plugin_category),
           )
async def tmgif(event):
    if event.fwd_from:
        return
    reply_to_id = await reply_id(event)
    if cute4:
        RAZAN = f"**{ROZA}**\n"
        RAZAN += f"✛━━━━━━━━━━━━━✛\n"
        RAZAN += f"**الـمتحـرڪـة الـرابـعـة**\n"
        await event.client.send_file(
            event.chat_id, cute4, caption=RAZAN, reply_to=reply_to_id
        )

#edit  ~ @lMl10l for l313l 
#جميع الحقوق محفوظة لسـورس الجوكر تخـمط تبيـن فشلـك

@l313l.ar_cmd(
    pattern="ك5$",
    command=("ك5", plugin_category),
           )

async def tmgif(event):
    if event.fwd_from:
        return
    reply_to_id = await reply_id(event)
    if cute5:
        RAZAN = f"**{ROZA}**\n"
        RAZAN += f"✛━━━━━━━━━━━━━✛\n"
        RAZAN += f"**الـمتحـرڪـة الـخامسـة**\n"
        await event.client.send_file(
            event.chat_id, cute5, caption=RAZAN, reply_to=reply_to_id
        )

#edit  ~ @lMl10l for l313l 
#جميع الحقوق محفوظة لسـورس الجوكر تخـمط تبيـن فشلـك

@l313l.ar_cmd(
    pattern="ك6$",
    command=("ك6", plugin_category),
           )

async def tmgif(event):
    if event.fwd_from:
        return
    reply_to_id = await reply_id(event)
    if cute6:
        RAZAN = f"**{ROZA}**\n"
        RAZAN += f"✛━━━━━━━━━━━━━✛\n"
        RAZAN += f"**الـمتحـرڪـة الـسادسـة**\n"
        await event.client.send_file(
            event.chat_id, cute6, caption=RAZAN, reply_to=reply_to_id
        )

#edit  ~ @lMl10l for l313l 
#جميع الحقوق محفوظة لسـورس الجوكر تخـمط تبيـن فشلـك

@l313l.ar_cmd(
    pattern="ك7$",
    command=("ك7", plugin_category),
           )
async def tmgif(event):
    if event.fwd_from:
        return
    reply_to_id = await reply_id(event)
    if cute7:
        RAZAN = f"**{ROZA}**\n"
        RAZAN += f"✛━━━━━━━━━━━━━✛\n"
        RAZAN += f"**الـمتحـرڪـة الـسـابعـة**"
        await event.client.send_file(
            event.chat_id, cute7, caption=RAZAN, reply_to=reply_to_id
        )
    
       
#edit  ~ @lMl10l for l313l 
#جميع الحقوق محفوظة لسـورس الجوكر تخـمط تبيـن فشلـك   
