from ._gif import *
# by ~ @lMl10l
